"""
Panel de chat para operadores (dashboard).

Permite ver las conversaciones apiladas, seguir el hilo en vivo, intervenir
manualmente y pausar/reanudar el bot (por conversación y de forma global).
Acceso restringido a administradores.
"""
from flask import Blueprint, render_template, jsonify, request
from flask_login import current_user

from app.decorators import require_roles
from app.models.operator import OperatorRole
from app.models.chat import ChatMessage, ChatConversation
from app.services.chat_service import ChatService
from app.services.system_config_service import SystemConfigService

chat_admin_bp = Blueprint('chat_admin', __name__, url_prefix='/dashboard/chat')


@chat_admin_bp.before_request
def _require_admin():
    """El panel de chat es exclusivo de administradores."""
    return require_roles(OperatorRole.ADMIN)


@chat_admin_bp.route('/')
def index():
    """Vista principal: lista de conversaciones + hilo."""
    return render_template(
        'chat/index.html',
        bot_paused_global=SystemConfigService.get_webchat_bot_paused(),
    )


@chat_admin_bp.route('/api/conversaciones')
def api_conversaciones():
    """Listado de conversaciones (polling)."""
    return jsonify({
        'ok': True,
        'bot_paused_global': SystemConfigService.get_webchat_bot_paused(),
        'conversations': ChatService.list_conversations(),
    })


@chat_admin_bp.route('/api/<int:conversation_id>/mensajes')
def api_mensajes(conversation_id: int):
    """Mensajes de una conversación (hilo completo o solo los nuevos)."""
    after_id = request.args.get('after', 0, type=int)
    if after_id:
        msgs = [
            m.to_dict()
            for m in ChatMessage.get_since(conversation_id, after_id)
        ]
    else:
        msgs = ChatService.history(conversation_id)
        ChatService.mark_read_by_operator(conversation_id)
    return jsonify({
        'ok': True,
        'messages': msgs,
        'typing': ChatService.is_typing(conversation_id, 'client'),
    })


@chat_admin_bp.route('/api/<int:conversation_id>/responder', methods=['POST'])
def api_responder(conversation_id: int):
    """Enviar una respuesta manual del operador."""
    data = request.get_json(silent=True) or {}
    msg = ChatService.operator_reply(
        conversation_id=conversation_id,
        operator_id=current_user.id,
        text=data.get('texto', ''),
    )
    if msg is None:
        return jsonify({'ok': False, 'error': 'mensaje_invalido'}), 400
    return jsonify({'ok': True, 'message': msg.to_dict()})


@chat_admin_bp.route('/api/<int:conversation_id>/typing', methods=['POST'])
def api_typing(conversation_id: int):
    """El operador está escribiendo (lo ve el cliente en su widget)."""
    ChatService.set_typing(conversation_id, 'operator')
    return jsonify({'ok': True})


@chat_admin_bp.route('/api/<int:conversation_id>/pausa', methods=['POST'])
def api_pausa(conversation_id: int):
    """Pausar/reanudar el bot en una conversación concreta."""
    data = request.get_json(silent=True) or {}
    paused = bool(data.get('paused', True))
    if not ChatService.set_bot_paused(conversation_id, paused):
        return jsonify({'ok': False, 'error': 'no_encontrada'}), 404
    return jsonify({'ok': True, 'paused': paused})


@chat_admin_bp.route('/api/pausa-global', methods=['POST'])
def api_pausa_global():
    """Pausar/reanudar el bot para TODAS las conversaciones."""
    data = request.get_json(silent=True) or {}
    paused = bool(data.get('paused', True))
    SystemConfigService.set_webchat_bot_paused(paused)
    return jsonify({'ok': True, 'paused': paused})

def _get_conversation(conversation_id: int):
    """Conversación por id, o None."""
    return ChatConversation.query.get(conversation_id)


@chat_admin_bp.route('/api/<int:conversation_id>/orden')
def api_orden(conversation_id: int):
    """Resumen de la orden activa del visitante (tarjeta del panel)."""
    conv = _get_conversation(conversation_id)
    if conv is None:
        return jsonify({'ok': False, 'error': 'no_encontrada'}), 404
    return jsonify({'ok': True, 'order': ChatService.order_summary(conv)})


@chat_admin_bp.route('/api/<int:conversation_id>/orden/verificar', methods=['POST'])
def api_orden_verificar(conversation_id: int):
    """Pago del cliente verificado: la orden pasa a procesamiento."""
    conv = _get_conversation(conversation_id)
    if conv is None:
        return jsonify({'ok': False, 'error': 'no_encontrada'}), 404

    ok, mensaje = ChatService.mark_payment_verified(conv, current_user.id)
    if not ok:
        return jsonify({'ok': False, 'error': mensaje}), 400
    return jsonify({'ok': True, 'message': mensaje})


@chat_admin_bp.route('/api/<int:conversation_id>/orden/no-encontrado', methods=['POST'])
def api_orden_no_encontrado(conversation_id: int):
    """El pago no aparece: se le pide al cliente revisar el comprobante."""
    conv = _get_conversation(conversation_id)
    if conv is None:
        return jsonify({'ok': False, 'error': 'no_encontrada'}), 404

    ok, mensaje = ChatService.mark_payment_not_found(conv)
    return jsonify({'ok': ok, 'message': mensaje})


@chat_admin_bp.route('/api/<int:conversation_id>/orden/completar', methods=['POST'])
def api_orden_completar(conversation_id: int):
    """Pago enviado al cliente: adjunta comprobante y completa la orden."""
    conv = _get_conversation(conversation_id)
    if conv is None:
        return jsonify({'ok': False, 'error': 'no_encontrada'}), 404

    ok, mensaje = ChatService.mark_payment_sent(
        conv, current_user.id, file_storage=request.files.get('archivo')
    )
    if not ok:
        return jsonify({'ok': False, 'error': mensaje}), 400
    return jsonify({'ok': True, 'message': mensaje})

