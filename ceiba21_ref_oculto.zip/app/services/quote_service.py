"""
Servicio de Cotizaciones (POO)
Maneja toda la lógica de negocio relacionada con cotizaciones
"""
from app.models import db, Quote, PaymentMethod, Currency, ExchangeRate


class QuoteService:
    """Servicio para gestionar cotizaciones"""

    @staticmethod
    def get_all_quotes():
        """Obtener todas las cotizaciones organizadas por método de pago"""
        quotes = Quote.query.join(PaymentMethod).join(Currency).order_by(
            PaymentMethod.display_order,
            Currency.code
        ).all()
        return quotes

    @staticmethod
    def get_quotes_by_payment_method(payment_method_code):
        """Obtener cotizaciones de un método de pago específico"""
        pm = PaymentMethod.query.filter_by(code=payment_method_code).first()
        if not pm:
            return []
        return Quote.query.filter_by(payment_method_id=pm.id).all()

    @staticmethod
    def _build_matrix(payment_methods, currencies):
        """
        Construye la matriz de cotizaciones para los métodos/monedas dados.

        Centraliza el armado del dict de cotizaciones para que tanto la matriz
        completa (dashboard) como la matriz pública compartan exactamente la
        misma estructura, sin duplicar el bucle.

        Args:
            payment_methods: Lista de PaymentMethod ya filtrada y ordenada.
            currencies: Lista de Currency ya filtrada y ordenada.

        Returns:
            dict con 'payment_methods', 'currencies' y 'quotes'.
        """
        quotes_dict = {}
        for pm in payment_methods:
            quotes_dict[pm.code] = {}
            for curr in currencies:
                quote = Quote.query.filter_by(
                    payment_method_id=pm.id,
                    currency_id=curr.id
                ).first()
                quotes_dict[pm.code][curr.code] = {
                    'id': quote.id if quote else None,
                    'value': float(quote.final_value) if quote and quote.final_value else 0,
                    'type': quote.value_type if quote else 'manual',
                    'formula': quote.usd_formula if quote else None,
                    'usd': float(quote.calculated_usd) if quote and quote.calculated_usd else 0,
                }

        return {
            'payment_methods': [pm.to_dict() for pm in payment_methods],
            'currencies': [curr.to_dict() for curr in currencies],
            'quotes': quotes_dict,
        }

    @staticmethod
    def get_quotes_matrix():
        """
        Obtener cotizaciones en formato matriz solo para entidades activas.

        Filtra payment_methods y currencies por active=True para que
        todas las páginas que consuman la matriz (dashboard) respeten el
        estado de activación configurado en el panel. Incluye TODOS los
        métodos activos, incluido el pivote 'REF' (el dashboard debe verlo
        y editarlo). Para superficies públicas usar get_public_quotes_matrix.

        Returns:
            dict con 'payment_methods', 'currencies' y 'quotes' (solo activos).
        """
        payment_methods = (
            PaymentMethod.query
            .filter_by(active=True)
            .order_by(PaymentMethod.display_order)
            .all()
        )
        currencies = (
            Currency.query
            .filter_by(active=True)
            .order_by(Currency.display_order, Currency.code)
            .all()
        )
        return QuoteService._build_matrix(payment_methods, currencies)

    @staticmethod
    def get_public_quotes_matrix():
        """
        Matriz de cotizaciones para superficies PÚBLICAS.

        Igual que get_quotes_matrix, pero los métodos se restringen a los
        visibles al público (PaymentMethod.get_visibles_publico), excluyendo
        los estructurales/pivote como 'REF'. Las monedas siguen siendo solo
        las activas. La estructura devuelta es idéntica a la matriz completa,
        de modo que los templates públicos no requieren cambios.

        Returns:
            dict con 'payment_methods', 'currencies' y 'quotes' (solo públicos).
        """
        payment_methods = PaymentMethod.get_visibles_publico()
        currencies = (
            Currency.query
            .filter_by(active=True)
            .order_by(Currency.display_order, Currency.code)
            .all()
        )
        return QuoteService._build_matrix(payment_methods, currencies)

    @staticmethod
    def get_cotizaciones_matrix():
        """
        Matriz para la TABLA pública /cotizaciones.

        Igual que get_public_quotes_matrix (métodos sin pivote), pero además
        excluye de las columnas las monedas ocultas en la tabla
        (Currency.OCULTAS_EN_COTIZACIONES, p. ej. 'USD'). Esas monedas siguen
        activas y disponibles en la calculadora pública; solo no se listan
        como columna en /cotizaciones, donde su cotización es redundante.

        La estructura devuelta es idéntica a las demás matrices, de modo que
        el template de la tabla no requiere cambios.

        Returns:
            dict con 'payment_methods', 'currencies' y 'quotes' para la tabla.
        """
        payment_methods = PaymentMethod.get_visibles_publico()
        currencies = Currency.get_visibles_en_cotizaciones()
        return QuoteService._build_matrix(payment_methods, currencies)

    @staticmethod
    def update_quote(quote_id, value_type=None, usd_value=None, usd_formula=None):
        """Actualizar una cotización"""
        quote = Quote.query.get(quote_id)
        if not quote:
            return None

        if value_type:
            quote.value_type = value_type
        if usd_value is not None:
            quote.usd_value = usd_value
        if usd_formula is not None:
            quote.usd_formula = usd_formula

        # Recalcular
        QuoteService.recalculate_quote(quote)

        db.session.commit()
        return quote

    @staticmethod
    def recalculate_quote(quote):
        """Recalcular una cotización individual"""
        # Calcular valor en USD
        if quote.value_type == 'manual':
            quote.calculated_usd = quote.usd_value
        elif quote.value_type == 'formula':
            try:
                calc_usd = eval(quote.usd_formula)
                quote.calculated_usd = calc_usd
            except (SyntaxError, NameError, TypeError, ValueError):
                quote.calculated_usd = 0

        # Obtener tasa de cambio y calcular valor final
        exchange_rate = ExchangeRate.query.filter_by(currency_id=quote.currency_id).first()
        if exchange_rate and quote.calculated_usd:
            quote.final_value = float(quote.calculated_usd) * float(exchange_rate.rate)

        return quote

    @staticmethod
    def recalculate_all_quotes():
        """Recalcular todas las cotizaciones (después de cambiar tasas de cambio)"""
        quotes = Quote.query.all()
        for quote in quotes:
            QuoteService.recalculate_quote(quote)
        db.session.commit()
        return len(quotes)

    @staticmethod
    def get_by_method_and_currency(payment_method_id: int, currency_id: int):
        """
        Obtiene una cotización específica por método de pago y moneda.

        Args:
            payment_method_id: ID del método de pago
            currency_id: ID de la moneda

        Returns:
            Quote si existe, None si no
        """
        return Quote.query.filter_by(
            payment_method_id=payment_method_id,
            currency_id=currency_id
        ).first()
