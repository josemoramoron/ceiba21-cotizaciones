"""
Migración: añade el valor 'bot' al tipo ENUM de roles de operador en PostgreSQL.

El rol de operador se almacena como un ENUM nativo de PostgreSQL, por lo que
añadir un valor nuevo requiere ``ALTER TYPE ... ADD VALUE`` (no lo hace
``db.create_all()``). Este script descubre el nombre real del tipo ENUM usado
por la columna ``operators.role`` y le añade 'bot' de forma idempotente.

Ejecutar en dev y en prod ANTES de sembrar el operador-bot::

    python scripts/migrate_add_bot_role.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import text

from app import create_app
from app.models import db


def main() -> int:
    """Añadir 'bot' al ENUM de roles de operador. Idempotente."""
    app = create_app()
    with app.app_context():
        engine = db.engine

        # Descubrir el nombre real del tipo ENUM de operators.role
        with engine.connect() as conn:
            type_name = conn.execute(text(
                "SELECT udt_name FROM information_schema.columns "
                "WHERE table_name = 'operators' AND column_name = 'role'"
            )).scalar()

        if not type_name:
            print("❌ No se encontró la columna operators.role. ¿Existe la tabla?")
            return 1

        print(f"🔎 Tipo ENUM detectado para operators.role: {type_name}")

        # ALTER TYPE ... ADD VALUE se ejecuta en autocommit (no dentro de una
        # transacción que luego use el valor). IF NOT EXISTS lo hace idempotente
        # (PostgreSQL 12+).
        with engine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            conn.execute(text(
                f"ALTER TYPE {type_name} ADD VALUE IF NOT EXISTS 'bot'"
            ))

        print("✅ Valor 'bot' disponible en el ENUM de roles (o ya existía).")
        return 0


if __name__ == '__main__':
    raise SystemExit(main())
